# Deployment script for Posit Connect
# Before running this script:
# 1. Get your API key from https://positconnect.prod.manulife.com/ -> User Settings -> API Keys
# 2. Replace YOUR_API_KEY_HERE with your actual API key

# Configuration
$SERVER_URL = "https://positconnect.prod.manulife.com/"
$SERVER_NAME = "manulife-posit"
$APP_TITLE = "EM Sovereign Credit Spread Analysis"
$PYTHON_EXE = "c:/code/em_debt/.venv/Scripts/python.exe"
$RSCONNECT_EXE = "c:/code/em_debt/.venv/Scripts/rsconnect.exe"

Write-Host "Installing rsconnect-python..." -ForegroundColor Cyan
& $PYTHON_EXE -m pip install rsconnect-python --index-url https://artifactory.platform.manulife.io/artifactory/api/pypi/pypi/simple

Write-Host "`nConfiguring Posit Connect server..." -ForegroundColor Cyan
Write-Host "Please enter your Posit Connect API key:"
$API_KEY = Read-Host

# Add server (will skip if already exists)
& $RSCONNECT_EXE add --server $SERVER_URL --name $SERVER_NAME --api-key $API_KEY 2>$null

Write-Host "`nDeploying app to Posit Connect..." -ForegroundColor Cyan
Set-Location "c:\code\em_debt"

# Try deployment without --python flag (let .python-version handle it)
Write-Host "Deploying to Connect (including input folder)..." -ForegroundColor Cyan
& $RSCONNECT_EXE deploy streamlit `
    --server $SERVER_NAME `
    --title $APP_TITLE `
    --entrypoint sovereing_score/app.py `
    --verbose `
    .

if ($LASTEXITCODE -ne 0) {
    Write-Host "`nDeployment failed. Trying alternative approach..." -ForegroundColor Yellow
    Write-Host "Please try deploying manually through Posit Connect web interface:" -ForegroundColor Cyan
    Write-Host "1. Go to https://positconnect.prod.manulife.com/" -ForegroundColor White
    Write-Host "2. Click 'Publish' -> 'Upload Content Bundle'" -ForegroundColor White
    Write-Host "3. Select deployment type: Streamlit" -ForegroundColor White
    Write-Host "4. Upload the following files/folders: sovereing_score/, input/, requirements.txt, .python-version" -ForegroundColor White
}
else {
    Write-Host "`nDeployment successful! Check your Posit Connect dashboard for the app URL." -ForegroundColor Green
}

Write-Host "`nDeployment complete!" -ForegroundColor Green
Write-Host "Your app should be available at: $SERVER_URL" -ForegroundColor Green
